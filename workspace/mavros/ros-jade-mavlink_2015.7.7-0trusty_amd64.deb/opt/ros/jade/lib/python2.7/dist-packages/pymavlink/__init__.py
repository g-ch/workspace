'''Python MAVLink library - see http://www.qgroundcontrol.org/mavlink/mavproxy_startpage'''
